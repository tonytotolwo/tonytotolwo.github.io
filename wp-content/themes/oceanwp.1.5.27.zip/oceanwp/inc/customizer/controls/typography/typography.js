( function($) {

	$( document ).ready(function () {

		$( '.oceanwp-typography-select' ).select2();

	} );

} )( jQuery );